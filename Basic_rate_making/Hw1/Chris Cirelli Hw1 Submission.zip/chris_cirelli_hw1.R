# Homework 1 ------------------------------------------------

# Clear Namespace
rm(list=ls())

# Import Packages
library(dplyr)
library(DBI)
library(readxl)
library(fitdistrplus)

# Set Working Directory
setwd("C:\\Users\\chris.cirelli\\Desktop\\repositories\\gsu_fall_2020\\Basic_rate_making\\data")

# Read Data
data <- read.csv("lossdata.csv")
col.names <- colnames(data)


###############################################################
## QUESTIONS 1 & 2
###############################################################

# Distribution  - Loss
hist(data$Loss, breaks=50, main='Loss Data', xlab='Incurred Amount')

# Fit Distribution To Data - Loss
plotdist(data$Loss, histo=TRUE, demp=TRUE)
descdist(data$Loss, boot=1000)


# Distribution ALAE
hist(data$ALAE, breaks=50, main='ALAE', xlab='ALAE')
plotdist(data$ALAE, histo=TRUE, demp=TRUE)
descdist(data$ALAE, boot=1000)


d.gamma <- fitdist(data$Loss/1000000, discrete=FALSE, "gamma", method='mle')
d.gamma
summary(d.gamma)

# Parameters
alpha = .506
beta  = 1/ 0.0152
mu = alpha * beta
std.dv = sqrt(alpha * beta ^2)
range = seq(0, mu + 10 * std.dv, 0.2)

# Draw Gamma Distribution 
y = dgamma(x = range, shape = alpha, rate = 1/beta)
plot(range, y, type='l', main='Gamma Distribution Fit 2 Loss Data', 
     xlab = 'incurred (per 100,000)', ylab = 'percentage')



###############################################################
## QUESTIONS 3
###############################################################

